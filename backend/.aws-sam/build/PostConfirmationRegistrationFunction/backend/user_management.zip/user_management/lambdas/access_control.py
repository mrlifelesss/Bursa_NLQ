from __future__ import annotations

import json
import logging
from typing import Any, Dict

from ..config import require_env
from ..exceptions import AuthorizationError, Conflict, NotFound
from ..services.credits import CreditManager

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    manager = CreditManager(
        users_table=require_env("USERS_TABLE_NAME"),
        orgs_table=require_env("ORGS_TABLE_NAME"),
    )

    try:
        user_id = event["requestContext"]["authorizer"]["claims"]["sub"]
    except KeyError:
        logger.error("Request is missing Cognito identity")
        return _response(401, {"error": "unauthorized"})

    tier_param = (event.get("queryStringParameters") or {}).get("tier")
    try:
        tier = int(tier_param or 0)
    except ValueError:
        return _response(400, {"error": "invalid_tier"})

    try:
        manager.authorise(user_id=user_id, requested_tier=tier)
    except NotFound:
        return _response(404, {"error": "not_found"})
    except Conflict:
        return _response(402, {"error": "credit_limit"})
    except AuthorizationError as exc:
        status = 403 if str(exc) != "payment_required" else 402
        return _response(status, {"error": str(exc) or "forbidden"})

    return _response(200, {"authorized": True})


def _response(status: int, body: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "statusCode": status,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body),
    }