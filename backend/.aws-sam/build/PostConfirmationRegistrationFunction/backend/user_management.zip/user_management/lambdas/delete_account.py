from __future__ import annotations

import json
import logging
from typing import Any, Dict

from ..config import optional_env, require_env
from ..services import self_service

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    try:
        user_id = event["requestContext"]["authorizer"]["claims"]["sub"]
    except KeyError:
        return _response(401, {"error": "unauthorized"})

    users_table = require_env("USERS_TABLE_NAME")
    orgs_table = require_env("ORGS_TABLE_NAME")
    user_pool_id = require_env("USER_POOL_ID")
    stripe_key = optional_env("STRIPE_API_KEY")

    try:
        self_service.delete_account(
            user_id=user_id,
            users_table=users_table,
            orgs_table=orgs_table,
            user_pool_id=user_pool_id,
            stripe_api_key=stripe_key,
        )
    except Exception:
        logger.exception("Failed to delete account for user %s", user_id)
        return _response(500, {"error": "internal_error"})

    return _response(200, {"message": "account_deleted"})


def _response(status: int, body: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "statusCode": status,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body),
    }