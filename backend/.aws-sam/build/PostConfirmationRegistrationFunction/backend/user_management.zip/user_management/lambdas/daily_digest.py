from __future__ import annotations

import json
import logging
from typing import Any, Dict

from ..config import require_env
from ..services.digest import DailyDigestService

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    service = DailyDigestService(
        users_table=require_env("USERS_TABLE_NAME"),
        watchlist_table=require_env("WATCHLIST_TABLE_NAME"),
        announcements_table=require_env("ANNOUNCEMENTS_TABLE_NAME"),
        announcements_gsi=require_env("ANNOUNCEMENTS_GSI_NAME"),
    )

    try:
        result = service.run()
    except Exception:
        logger.exception("Daily digest processing failed")
        return _response(500, {"error": "internal_error"})

    return _response(200, result)


def _response(status: int, body: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "statusCode": status,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body),
    }