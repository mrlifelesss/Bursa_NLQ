from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional

from ..config import optional_env, require_env
from ..services.billing import BillingService
from ..services.organizations import find_org_by_stripe_customer
from ..services.users import ensure_user
from ..stripe_utils import configure, first_line_item_price_id, plan_catalogue, verify_webhook

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    users_table = require_env("USERS_TABLE_NAME")
    orgs_table = require_env("ORGS_TABLE_NAME")
    user_pool_id = require_env("USER_POOL_ID")

    configure(require_env("STRIPE_API_KEY"))
    webhook_secret = require_env("STRIPE_WEBHOOK_SECRET")
    plans = plan_catalogue()

    billing = BillingService(orgs_table=orgs_table, users_table=users_table, user_pool_id=user_pool_id)
    stripe_index = optional_env("ORGS_TABLE_STRIPE_CUSTOMER_GSI")

    payload = event.get("body", "")
    signature = (event.get("headers") or {}).get("stripe-signature")

    if not payload or not signature:
        logger.error("Stripe webhook missing payload or signature")
        return _response(400, {"error": "invalid_request"})

    try:
        stripe_event = verify_webhook(payload, signature, webhook_secret)
    except Exception:
        logger.exception("Failed to verify Stripe signature")
        return _response(400, {"error": "invalid_signature"})

    event_type = stripe_event.get("type")
    data_object = stripe_event.get("data", {}).get("object", {})
    logger.info("Processing Stripe event %s", event_type)

    try:
        if event_type == "checkout.session.completed":
            _handle_checkout_completed(data_object, plans, billing, users_table)
        elif event_type == "customer.subscription.updated":
            _handle_subscription_updated(data_object, plans, billing, orgs_table, stripe_index)
        elif event_type == "customer.subscription.deleted":
            _handle_subscription_deleted(data_object, billing, orgs_table, stripe_index)
        elif event_type == "invoice.payment_failed":
            _handle_payment_failed(data_object, billing, orgs_table, stripe_index)
        else:
            logger.info("Event %s is not handled; acknowledging", event_type)
    except Exception:
        logger.exception("Stripe webhook handler failed")
        return _response(500, {"error": "internal_error"})

    return _response(200, {"status": "ok"})


def _handle_checkout_completed(
    session: Dict[str, Any],
    plans: Dict[str, Any],
    billing: BillingService,
    users_table: str,
) -> None:
    user_id = session.get("client_reference_id")
    customer_id = session.get("customer")
    subscription_id = session.get("subscription")
    session_id = session.get("id")

    if not all([user_id, customer_id, subscription_id, session_id]):
        logger.error("Checkout session missing identifiers: %s", json.dumps(session))
        return

    try:
        price_id = first_line_item_price_id(session_id)
    except Exception:
        logger.exception("Failed to retrieve price for session %s", session_id)
        return

    plan = plans.get(price_id)
    if not plan:
        logger.warning("Price %s is not mapped to a plan; acknowledging", price_id)
        return

    user = ensure_user(user_id, users_table)
    organization_id = user["organizationId"]

    billing.upgrade_subscription(
        organization_id=organization_id,
        user_id=user_id,
        plan=plan,
        stripe_customer_id=customer_id,
        stripe_subscription_id=subscription_id,
    )


def _handle_subscription_updated(
    subscription: Dict[str, Any],
    plans: Dict[str, Any],
    billing: BillingService,
    orgs_table: str,
    stripe_index: Optional[str],
) -> None:
    customer_id = subscription.get("customer")
    if not customer_id:
        logger.warning("Subscription update missing customer id")
        return

    org = find_org_by_stripe_customer(customer_id, orgs_table, stripe_index)
    if not org:
        logger.warning("No organization found for Stripe customer %s", customer_id)
        return

    if subscription.get("cancel_at_period_end"):
        billing.mark_pending_cancellation(org["organizationId"])
        return

    items = subscription.get("items", {}).get("data", [])
    price = items[0].get("price", {}) if items else {}
    price_id = price.get("id")

    if not price_id:
        logger.warning("Subscription update missing price id for customer %s", customer_id)
        return

    plan = plans.get(price_id)
    if not plan:
        logger.info("Price %s not mapped to a plan; treating as acknowledged", price_id)
        return

    owner_id = org.get("ownerId")
    if not owner_id:
        logger.warning("Organization %s has no ownerId recorded", org["organizationId"])
        return

    billing.upgrade_subscription(
        organization_id=org["organizationId"],
        user_id=owner_id,
        plan=plan,
        stripe_customer_id=customer_id,
        stripe_subscription_id=subscription.get("id"),
    )


def _handle_subscription_deleted(
    subscription: Dict[str, Any],
    billing: BillingService,
    orgs_table: str,
    stripe_index: Optional[str],
) -> None:
    customer_id = subscription.get("customer")
    if not customer_id:
        return
    org = find_org_by_stripe_customer(customer_id, orgs_table, stripe_index)
    if not org:
        return
    owner_id = org.get("ownerId")
    if not owner_id:
        logger.warning("Organization %s missing ownerId while downgrading", org["organizationId"])
        return
    billing.downgrade_to_free(org["organizationId"], owner_id)


def _handle_payment_failed(
    invoice: Dict[str, Any],
    billing: BillingService,
    orgs_table: str,
    stripe_index: Optional[str],
) -> None:
    customer_id = invoice.get("customer")
    if not customer_id:
        return
    org = find_org_by_stripe_customer(customer_id, orgs_table, stripe_index)
    if not org:
        return
    billing.mark_past_due(org["organizationId"])


def _response(status: int, body: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "statusCode": status,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body),
    }