from __future__ import annotations

import json
import logging
from typing import Any, Dict

from botocore.exceptions import ClientError

from ..services import self_service

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    try:
        payload = json.loads(event.get("body") or "{}")
    except json.JSONDecodeError:
        return _response(400, {"error": "invalid_json"})

    previous_password = payload.get("previousPassword")
    new_password = payload.get("newPassword")
    if not previous_password or not new_password:
        return _response(400, {"error": "missing_fields"})

    auth_header = (event.get("headers") or {}).get("Authorization", "")
    parts = auth_header.split()
    if len(parts) != 2:
        return _response(401, {"error": "unauthorized"})
    access_token = parts[1]

    try:
        self_service.change_password(access_token, previous_password, new_password)
    except ClientError as exc:
        error_code = exc.response.get("Error", {}).get("Code")
        if error_code == "NotAuthorizedException":
            return _response(400, {"error": "incorrect_previous_password"})
        if error_code == "InvalidPasswordException":
            return _response(400, {"error": exc.response.get("Error", {}).get("Message")})
        logger.exception("Cognito change_password failed")
        return _response(500, {"error": "internal_error"})
    except Exception:
        logger.exception("Unexpected failure while changing password")
        return _response(500, {"error": "internal_error"})

    return _response(200, {"message": "password_changed"})


def _response(status: int, body: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "statusCode": status,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body),
    }