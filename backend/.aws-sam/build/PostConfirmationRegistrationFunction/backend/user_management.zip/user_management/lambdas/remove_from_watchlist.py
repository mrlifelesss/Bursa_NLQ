from __future__ import annotations

import json
import logging
from typing import Any, Dict

from ..config import require_env
from ..services import watchlist

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    try:
        user_id = event["requestContext"]["authorizer"]["claims"]["sub"]
    except KeyError:
        return _response(401, {"error": "unauthorized"})

    company_id = (event.get("pathParameters") or {}).get("companyId")
    if not company_id:
        return _response(400, {"error": "company_required"})

    table_name = require_env("WATCHLIST_TABLE_NAME")

    try:
        watchlist.remove_item(user_id=user_id, company_id=company_id, table_name=table_name)
    except Exception:
        logger.exception("Failed to remove %s from watchlist for user %s", company_id, user_id)
        return _response(500, {"error": "internal_error"})

    return {
        "statusCode": 204,
        "headers": {"Content-Type": "application/json"},
        "body": "",
    }


def _response(status: int, body: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "statusCode": status,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body),
    }