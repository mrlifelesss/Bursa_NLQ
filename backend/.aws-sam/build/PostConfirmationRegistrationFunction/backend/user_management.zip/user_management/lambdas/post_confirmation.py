from __future__ import annotations

import json
import logging
from typing import Any, Dict

from ..config import require_env
from ..services.onboarding import OnboardingService

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    logger.info("Received Cognito post confirmation event: %s", json.dumps(event))

    user_id = event.get("userName")
    user_attrs = event.get("request", {}).get("userAttributes", {})
    email = user_attrs.get("email")
    name = user_attrs.get("name")

    if not user_id or not email:
        logger.error("userName or email missing from Cognito event; skipping provisioning")
        return event

    service = OnboardingService(
        users_table=require_env("USERS_TABLE_NAME"),
        orgs_table=require_env("ORGS_TABLE_NAME"),
        user_pool_id=require_env("USER_POOL_ID"),
    )

    try:
        service.provision_user(user_id=user_id, email=email, name=name)
    except Exception:
        logger.exception("Failed to provision user %s", user_id)
        raise

    return event