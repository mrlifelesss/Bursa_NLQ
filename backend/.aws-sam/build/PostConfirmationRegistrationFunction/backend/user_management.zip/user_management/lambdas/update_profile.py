from __future__ import annotations

import json
import logging
from typing import Any, Dict

from ..config import require_env
from ..services import self_service

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    users_table = require_env("USERS_TABLE_NAME")

    try:
        user_id = event["requestContext"]["authorizer"]["claims"]["sub"]
    except KeyError:
        return _response(401, {"error": "unauthorized"})

    try:
        payload = json.loads(event.get("body") or "{}")
    except json.JSONDecodeError:
        return _response(400, {"error": "invalid_json"})

    try:
        self_service.update_profile(user_id=user_id, table_name=users_table, payload=payload)
    except ValueError as exc:
        return _response(400, {"error": str(exc) or "invalid_request"})
    except Exception:
        logger.exception("Failed to update profile for user %s", user_id)
        return _response(500, {"error": "internal_error"})

    return _response(200, {"message": "profile_updated"})


def _response(status: int, body: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "statusCode": status,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body),
    }