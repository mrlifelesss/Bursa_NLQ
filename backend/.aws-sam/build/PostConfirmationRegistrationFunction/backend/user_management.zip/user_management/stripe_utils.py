from __future__ import annotations

from functools import lru_cache
from typing import Dict

import stripe

from .config import StripePlanConfig, build_stripe_plan_map


def configure(api_key: str) -> None:
    if not api_key:
        raise ValueError("Stripe API key must be provided")
    if stripe.api_key != api_key:
        stripe.api_key = api_key


def plan_catalogue() -> Dict[str, StripePlanConfig]:
    return build_stripe_plan_map()


def verify_webhook(payload: str, signature: str, secret: str):
    if not secret:
        raise ValueError("Stripe webhook secret is required for signature verification")
    return stripe.Webhook.construct_event(payload=payload, sig_header=signature, secret=secret)


def first_line_item_price_id(session_id: str) -> str:
    items = stripe.checkout.Session.list_line_items(session_id, limit=1)
    data = items.get("data", [])
    if not data:
        raise ValueError("Checkout session does not contain any line items")
    price = data[0].get("price") or {}
    price_id = price.get("id")
    if not price_id:
        raise ValueError("Line item is missing a price identifier")
    return price_id