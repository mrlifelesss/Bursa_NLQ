from __future__ import annotations


class UserManagementError(Exception):
    """Base class for domain-specific exceptions."""


class NotFound(UserManagementError):
    """Raised when an expected record is missing."""


class Conflict(UserManagementError):
    """Raised for state conflicts such as exhausted credits."""


class AuthorizationError(UserManagementError):
    """Raised when a request cannot be fulfilled due to entitlement restrictions."""


class RetryableError(UserManagementError):
    """Raised when an operation failed but a retry may succeed."""