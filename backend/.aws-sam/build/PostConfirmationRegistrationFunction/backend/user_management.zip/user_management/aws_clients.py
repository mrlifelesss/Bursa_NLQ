from __future__ import annotations

from functools import lru_cache
from typing import Any

import boto3
from botocore.config import Config as BotoConfig


BOTO_CONFIG = BotoConfig(retries={"max_attempts": 3, "mode": "standard"})


@lru_cache(maxsize=1)
def dynamodb_resource():
    return boto3.resource("dynamodb", config=BOTO_CONFIG)


def dynamodb_table(name: str):
    return dynamodb_resource().Table(name)


@lru_cache(maxsize=1)
def cognito_idp_client():
    return boto3.client("cognito-idp", config=BOTO_CONFIG)


@lru_cache(maxsize=1)
def ses_client():
    return boto3.client("ses", config=BOTO_CONFIG)


@lru_cache(maxsize=1)
def stripe_logs_client():
    """Placeholder for future integrations that require another client."""
    return boto3.client("logs", config=BOTO_CONFIG)