from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Dict, Optional

from boto3.dynamodb.conditions import Key

from .. import aws_clients
from ..exceptions import NotFound


def _org_table(table_name: str):
    return aws_clients.dynamodb_table(table_name)


def fetch_org(org_id: str, table_name: str) -> Optional[Dict[str, any]]:
    if not org_id:
        return None
    response = _org_table(table_name).get_item(Key={"organizationId": org_id})
    return response.get("Item")


def ensure_org(org_id: str, table_name: str) -> Dict[str, any]:
    organization = fetch_org(org_id, table_name)
    if not organization:
        raise NotFound(f"Organization '{org_id}' was not found")
    return organization


def store_org(item: Dict[str, any], table_name: str) -> None:
    _org_table(table_name).put_item(Item=item)


def update_org(org_id: str, table_name: str, expression: str, values: Dict[str, any]) -> None:
    _org_table(table_name).update_item(
        Key={"organizationId": org_id},
        UpdateExpression=expression,
        ExpressionAttributeValues=values,
    )


def find_org_by_stripe_customer(stripe_customer_id: str, table_name: str, index_name: Optional[str]) -> Optional[Dict[str, any]]:
    if not stripe_customer_id or not index_name:
        return None
    table = _org_table(table_name)
    response = table.query(
        IndexName=index_name,
        KeyConditionExpression=Key("stripeCustomerId").eq(stripe_customer_id),
        Limit=1,
    )
    items = response.get("Items", [])
    return items[0] if items else None


def next_reset_date(days: int) -> str:
    now = datetime.now(timezone.utc)
    return (now + timedelta(days=days)).isoformat()


def should_reset_credits(org_record: Dict[str, any]) -> bool:
    reset_at = org_record.get("creditCycleResetDate")
    if not reset_at:
        return False
    try:
        scheduled = datetime.fromisoformat(reset_at)
    except ValueError:
        return False
    return datetime.now(timezone.utc) >= scheduled


def reset_credit_state(org_record: Dict[str, any], table_name: str, users_table_name: str) -> Dict[str, any]:
    # Helper retained for future extensibility � currently the reset is handled inline.
    return org_record