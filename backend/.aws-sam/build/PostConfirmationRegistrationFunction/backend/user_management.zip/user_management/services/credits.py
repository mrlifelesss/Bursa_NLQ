from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Dict, Optional, Tuple

from botocore.exceptions import ClientError

from .. import aws_clients
from ..config import FREE_TIER_LIMITS, FREE_TIER_WELCOME_DAYS
from ..exceptions import AuthorizationError, Conflict, NotFound

logger = logging.getLogger(__name__)


class CreditManager:
    def __init__(self, users_table: str, orgs_table: str) -> None:
        self._users_table_name = users_table
        self._orgs_table_name = orgs_table
        self._users_table = aws_clients.dynamodb_table(users_table)
        self._orgs_table = aws_clients.dynamodb_table(orgs_table)

    def authorise(self, user_id: str, requested_tier: int, now: Optional[datetime] = None) -> Dict[str, any]:
        if requested_tier not in (1, 2):
            raise AuthorizationError(f"Tier '{requested_tier}' is not supported")

        user = self._load_user(user_id)
        org = self._load_org(user["organizationId"], now or datetime.now(timezone.utc))
        self._enforce_status(org)

        if requested_tier == 1:
            self._maybe_consume_credit(org, "tier1", now)
        else:
            self._handle_tier_two(org, now)

        return org

    def _load_user(self, user_id: str) -> Dict[str, any]:
        response = self._users_table.get_item(Key={"userId": user_id})
        user = response.get("Item")
        if not user:
            raise NotFound(f"User '{user_id}' does not exist")
        return user

    def _load_org(self, org_id: str, current_time: datetime) -> Dict[str, any]:
        response = self._orgs_table.get_item(Key={"organizationId": org_id})
        org = response.get("Item")
        if not org:
            raise NotFound(f"Organization '{org_id}' does not exist")

        reset_at = org.get("creditCycleResetDate")
        if reset_at:
            try:
                reset_time = datetime.fromisoformat(reset_at)
            except ValueError:
                reset_time = None
        else:
            reset_time = None

        if reset_time and current_time >= reset_time:
            next_reset = (current_time + timedelta(days=FREE_TIER_WELCOME_DAYS)).isoformat()
            logger.info("Resetting monthly credits for org %s", org_id)
            self._orgs_table.update_item(
                Key={"organizationId": org_id},
                UpdateExpression=(
                    "SET tier1CreditsUsed = :zero, tier2CreditsUsed = :zero, creditCycleResetDate = :next"
                ),
                ExpressionAttributeValues={
                    ":zero": 0,
                    ":next": next_reset,
                },
            )
            org["tier1CreditsUsed"] = 0
            org["tier2CreditsUsed"] = 0
            org["creditCycleResetDate"] = next_reset

        return org

    def _enforce_status(self, org: Dict[str, any]) -> None:
        status = (org.get("subscriptionStatus") or "active").lower()
        if status == "past_due":
            raise AuthorizationError("payment_required")

    def _maybe_consume_credit(self, org: Dict[str, any], tier_key: str, now: Optional[datetime]) -> None:
        credit_field = f"{tier_key}CreditsUsed"
        limit_field = f"{tier_key}Limit"

        limit = int(org.get(limit_field, 0))
        used = int(org.get(credit_field, 0))

        if limit == -1:
            return  # Unlimited tier

        if used >= limit:
            raise Conflict("credit_limit_reached")

        try:
            self._orgs_table.update_item(
                Key={"organizationId": org["organizationId"]},
                UpdateExpression=f"SET {credit_field} = {credit_field} + :one",
                ConditionExpression=f"{credit_field} < :limit",
                ExpressionAttributeValues={
                    ":one": 1,
                    ":limit": limit,
                },
            )
            org[credit_field] = used + 1
        except ClientError as exc:
            if exc.response.get("Error", {}).get("Code") == "ConditionalCheckFailedException":
                raise Conflict("credit_limit_reached") from exc
            raise

    def _handle_tier_two(self, org: Dict[str, any], now: Optional[datetime]) -> None:
        now = now or datetime.now(timezone.utc)
        tier = (org.get("subscriptionTier") or "").lower()

        limit = int(org.get("tier2Limit", 0))
        used = int(org.get("tier2CreditsUsed", 0))

        if limit == -1:
            return

        if tier == "free":
            expiry = org.get("welcomeCreditsExpiry")
            if not expiry:
                raise AuthorizationError("welcome_credits_unavailable")
            try:
                expiry_time = datetime.fromisoformat(expiry)
            except ValueError:
                raise AuthorizationError("welcome_credits_expired")
            if now >= expiry_time:
                raise AuthorizationError("welcome_credits_expired")

        if used >= limit:
            raise Conflict("credit_limit_reached")

        self._maybe_consume_credit(org, "tier2", now)