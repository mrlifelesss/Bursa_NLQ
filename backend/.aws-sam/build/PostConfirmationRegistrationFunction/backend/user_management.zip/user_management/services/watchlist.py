from __future__ import annotations

import logging
from typing import Dict, Iterable, List

from .. import aws_clients

logger = logging.getLogger(__name__)


def add_item(user_id: str, company_id: str, table_name: str) -> None:
    item = {"userId": user_id, "companyId": company_id}
    aws_clients.dynamodb_table(table_name).put_item(Item=item)


def remove_item(user_id: str, company_id: str, table_name: str) -> None:
    key = {"userId": user_id, "companyId": company_id}
    aws_clients.dynamodb_table(table_name).delete_item(Key=key)


def scan_all(table_name: str) -> List[Dict[str, str]]:
    table = aws_clients.dynamodb_table(table_name)
    items: List[Dict[str, str]] = []
    params: Dict[str, any] = {}
    while True:
        response = table.scan(**params)
        items.extend(response.get("Items", []))
        last_key = response.get("LastEvaluatedKey")
        if not last_key:
            break
        params["ExclusiveStartKey"] = last_key
    return items