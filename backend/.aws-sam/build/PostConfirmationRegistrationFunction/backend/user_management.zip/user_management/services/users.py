from __future__ import annotations

from typing import Dict, Iterable, Optional

import boto3

from .. import aws_clients
from ..exceptions import NotFound


def _users_table(table_name: str):
    return aws_clients.dynamodb_table(table_name)


def fetch_user(user_id: str, table_name: str) -> Optional[Dict[str, any]]:
    if not user_id:
        return None
    response = _users_table(table_name).get_item(Key={"userId": user_id})
    return response.get("Item")


def ensure_user(user_id: str, table_name: str) -> Dict[str, any]:
    user = fetch_user(user_id, table_name)
    if not user:
        raise NotFound(f"User '{user_id}' was not found")
    return user


def store_user(item: Dict[str, any], table_name: str) -> None:
    _users_table(table_name).put_item(Item=item)


def delete_user(user_id: str, table_name: str) -> None:
    _users_table(table_name).delete_item(Key={"userId": user_id})


def update_user(user_id: str, table_name: str, expression: str, values: Dict[str, any]) -> None:
    _users_table(table_name).update_item(
        Key={"userId": user_id},
        UpdateExpression=expression,
        ExpressionAttributeValues=values,
    )


def batch_get_users(user_ids: Iterable[str], table_name: str) -> Dict[str, Dict[str, any]]:
    ids = [uid for uid in user_ids if uid]
    if not ids:
        return {}

    dynamodb = aws_clients.dynamodb_resource()
    keys = [{"userId": uid} for uid in ids]
    results: Dict[str, Dict[str, any]] = {}

    for start in range(0, len(keys), 100):
        chunk = keys[start : start + 100]
        response = dynamodb.batch_get_item(RequestItems={table_name: {"Keys": chunk}})
        for item in response.get("Responses", {}).get(table_name, []):
            results[item["userId"]] = item

    return results