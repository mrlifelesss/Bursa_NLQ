from __future__ import annotations

import logging
import uuid
from datetime import datetime, timedelta, timezone
from typing import Dict

from .. import aws_clients
from ..config import DEFAULT_LANGUAGE, FREE_TIER_GROUP_NAME, FREE_TIER_LIMITS, FREE_TIER_WELCOME_DAYS

logger = logging.getLogger(__name__)


class OnboardingService:
    def __init__(self, users_table: str, orgs_table: str, user_pool_id: str) -> None:
        self._users_table = aws_clients.dynamodb_table(users_table)
        self._orgs_table = aws_clients.dynamodb_table(orgs_table)
        self._user_pool_id = user_pool_id
        self._cognito = aws_clients.cognito_idp_client()

    def provision_user(self, user_id: str, email: str, name: str | None = None) -> Dict[str, any]:
        organization_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc)
        reset = now + timedelta(days=FREE_TIER_WELCOME_DAYS)

        user_item = {
            "userId": user_id,
            "organizationId": organization_id,
            "email": email,
            "name": name or "New User",
            "roleInOrg": "owner",
            "languagePreference": DEFAULT_LANGUAGE,
            "createdAt": now.isoformat(),
        }

        org_item = {
            "organizationId": organization_id,
            "subscriptionTier": "free",
            "subscriptionStatus": "active",
            "createdAt": now.isoformat(),
            "stripeCustomerId": None,
            "stripeSubscriptionId": None,
            "tier1Limit": FREE_TIER_LIMITS.tier1,
            "tier1CreditsUsed": 0,
            "tier2Limit": FREE_TIER_LIMITS.tier2,
            "tier2CreditsUsed": 0,
            "creditCycleResetDate": reset.isoformat(),
            "welcomeCreditsExpiry": reset.isoformat(),
            "ownerId": user_id,
        }

        logger.info("Persisting new user %s in organization %s", user_id, organization_id)
        self._users_table.put_item(Item=user_item)
        self._orgs_table.put_item(Item=org_item)

        logger.info("Adding user %s to Cognito group %s", user_id, FREE_TIER_GROUP_NAME)
        self._cognito.admin_add_user_to_group(
            UserPoolId=self._user_pool_id,
            Username=user_id,
            GroupName=FREE_TIER_GROUP_NAME,
        )

        return {"user": user_item, "organization": org_item}