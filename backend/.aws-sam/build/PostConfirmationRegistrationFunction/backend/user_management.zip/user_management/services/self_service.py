from __future__ import annotations

import logging
from typing import Dict, Optional

import stripe

from .. import aws_clients
from ..stripe_utils import configure

logger = logging.getLogger(__name__)


def update_profile(user_id: str, table_name: str, payload: Dict[str, str]) -> None:
    allowed_fields = {"name", "languagePreference"}
    updates = {key: value for key, value in payload.items() if key in allowed_fields and value}

    if "languagePreference" in updates and updates["languagePreference"] not in ("en", "he"):
        raise ValueError("languagePreference must be 'en' or 'he'")

    if not updates:
        raise ValueError("No supported fields to update")

    expressions = []
    values: Dict[str, str] = {}
    for idx, (key, value) in enumerate(updates.items(), start=1):
        placeholder = f":v{idx}"
        expressions.append(f"{key} = {placeholder}")
        values[placeholder] = value

    aws_clients.dynamodb_table(table_name).update_item(
        Key={"userId": user_id},
        UpdateExpression="SET " + ", ".join(expressions),
        ExpressionAttributeValues=values,
    )


def change_password(access_token: str, previous_password: str, new_password: str) -> None:
    client = aws_clients.cognito_idp_client()
    client.change_password(
        AccessToken=access_token,
        PreviousPassword=previous_password,
        ProposedPassword=new_password,
    )


def delete_account(
    user_id: str,
    users_table: str,
    orgs_table: str,
    user_pool_id: str,
    stripe_api_key: Optional[str] = None,
) -> None:
    users = aws_clients.dynamodb_table(users_table)
    orgs = aws_clients.dynamodb_table(orgs_table)

    user_resp = users.get_item(Key={"userId": user_id})
    user = user_resp.get("Item")
    if not user:
        logger.info("User %s already deleted", user_id)
        return

    org_id = user.get("organizationId")
    org = None
    if org_id:
        org_resp = orgs.get_item(Key={"organizationId": org_id})
        org = org_resp.get("Item")

    subscription_id = org.get("stripeSubscriptionId") if org else None
    if subscription_id and stripe_api_key:
        configure(stripe_api_key)
        try:
            stripe.Subscription.delete(subscription_id)
        except stripe.error.InvalidRequestError:
            logger.warning("Stripe subscription %s was already canceled", subscription_id)

    client = aws_clients.cognito_idp_client()
    try:
        client.admin_delete_user(UserPoolId=user_pool_id, Username=user_id)
    except client.exceptions.UserNotFoundException:  # type: ignore[attr-defined]
        logger.info("Cognito user %s already deleted", user_id)

    if org_id and org:
        orgs.delete_item(Key={"organizationId": org_id})
    users.delete_item(Key={"userId": user_id})