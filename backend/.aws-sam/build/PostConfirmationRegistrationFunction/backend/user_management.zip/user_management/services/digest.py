from __future__ import annotations

import json
import logging
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Dict, Iterable, List, Optional

from boto3.dynamodb.conditions import Key

from .. import aws_clients
from ..config import digest_template_names, source_email_address
from ..services import watchlist as watchlist_service
from ..services.users import batch_get_users

logger = logging.getLogger(__name__)


class DailyDigestService:
    def __init__(
        self,
        users_table: str,
        watchlist_table: str,
        announcements_table: str,
        announcements_gsi: str,
    ) -> None:
        self._users_table_name = users_table
        self._watchlist_table_name = watchlist_table
        self._announcements_table = aws_clients.dynamodb_table(announcements_table)
        self._announcements_gsi = announcements_gsi
        self._ses = aws_clients.ses_client()

    def run(self, now: Optional[datetime] = None, lookback_hours: int = 24) -> Dict[str, int]:
        now = now or datetime.now(timezone.utc)
        since = now - timedelta(hours=lookback_hours)

        announcements = self._recent_announcements(since, now)
        if not announcements:
            logger.info("No announcements found in lookback window")
            return {"announcements": 0, "emails_sent": 0, "emails_failed": 0}

        watchlist_entries = watchlist_service.scan_all(self._watchlist_table_name)
        if not watchlist_entries:
            logger.info("No watchlist entries present; skipping digest")
            return {"announcements": len(announcements), "emails_sent": 0, "emails_failed": 0}

        digest_map = self._build_digest_map(announcements, watchlist_entries)
        if not digest_map:
            logger.info("No users match announcements for digest")
            return {"announcements": len(announcements), "emails_sent": 0, "emails_failed": 0}

        user_details = batch_get_users(digest_map.keys(), self._users_table_name)
        templates = digest_template_names()
        source_email = source_email_address()
        if not source_email:
            raise RuntimeError("SOURCE_EMAIL environment variable must be configured for SES digests")

        sent = 0
        failed = 0
        for user_id, announcement_list in digest_map.items():
            user = user_details.get(user_id)
            if not user or "email" not in user:
                logger.warning("Skipping digest for user %s; missing email", user_id)
                failed += 1
                continue
            template = templates.get(user.get("languagePreference", "en"), templates["en"])
            payload = self._build_template_payload(user, announcement_list)
            try:
                self._ses.send_templated_email(
                    Source=source_email,
                    Destination={"ToAddresses": [user["email"]]},
                    Template=template,
                    TemplateData=json.dumps(payload),
                )
                sent += 1
            except Exception:
                logger.exception("Failed to send digest to %s", user["email"])
                failed += 1

        return {"announcements": len(announcements), "emails_sent": sent, "emails_failed": failed}

    def _recent_announcements(self, start: datetime, end: datetime) -> List[Dict[str, any]]:
        response = self._announcements_table.query(
            IndexName=self._announcements_gsi,
            KeyConditionExpression=Key("status").eq("PUBLISHED") & Key("publicationDate").between(start.isoformat(), end.isoformat()),
        )
        return response.get("Items", [])

    def _build_digest_map(self, announcements: List[Dict[str, any]], watchlist_entries: List[Dict[str, str]]):
        watch_map: Dict[str, List[str]] = defaultdict(list)
        for entry in watchlist_entries:
            company_id = entry.get("companyId")
            user_id = entry.get("userId")
            if company_id and user_id:
                watch_map[company_id].append(user_id)

        digest: Dict[str, List[Dict[str, any]]] = defaultdict(list)
        for announcement in announcements:
            company_id = announcement.get("companyId")
            if not company_id:
                continue
            for user_id in watch_map.get(company_id, []):
                digest[user_id].append(announcement)
        return digest

    @staticmethod
    def _build_template_payload(user: Dict[str, any], announcements: List[Dict[str, any]]) -> Dict[str, any]:
        return {
            "name": user.get("name", "Investor"),
            "update_count": len(announcements),
            "announcements": [
                {
                    "companyName": item.get("companyName", "N/A"),
                    "reportTitle": item.get("title", "N/A"),
                    "summary": item.get("tier1Summary", "Summary unavailable"),
                    "link": f"https://yourapp.com/announcement/{item.get('announcementId')}"
                }
                for item in announcements
            ],
        }