from __future__ import annotations

import logging
from typing import Dict, Optional

from botocore.exceptions import ClientError

from .. import aws_clients
from ..config import FREE_TIER_GROUP_NAME, FREE_TIER_LIMITS, StripePlanConfig
from ..exceptions import NotFound

logger = logging.getLogger(__name__)


class BillingService:
    def __init__(self, orgs_table: str, users_table: str, user_pool_id: str) -> None:
        self._orgs_table_name = orgs_table
        self._users_table_name = users_table
        self._orgs_table = aws_clients.dynamodb_table(orgs_table)
        self._users_table = aws_clients.dynamodb_table(users_table)
        self._user_pool_id = user_pool_id
        self._cognito = aws_clients.cognito_idp_client()

    def upgrade_subscription(
        self,
        organization_id: str,
        user_id: str,
        plan: StripePlanConfig,
        stripe_customer_id: str,
        stripe_subscription_id: str,
    ) -> None:
        logger.info("Upgrading org %s to %s", organization_id, plan.tier_name)
        self._orgs_table.update_item(
            Key={"organizationId": organization_id},
            UpdateExpression=(
                "SET subscriptionTier = :tier, subscriptionStatus = :status, "
                "stripeCustomerId = :customer, stripeSubscriptionId = :subscription, "
                "tier1Limit = :tier1_limit, tier2Limit = :tier2_limit, welcomeCreditsExpiry = :welcome"
            ),
            ExpressionAttributeValues={
                ":tier": plan.tier_name,
                ":status": "active",
                ":customer": stripe_customer_id,
                ":subscription": stripe_subscription_id,
                ":tier1_limit": plan.limits.tier1,
                ":tier2_limit": plan.limits.tier2,
                ":welcome": None,
            },
        )
        self._swap_cognito_group(user_id, plan.cognito_group)

    def mark_pending_cancellation(self, organization_id: str) -> None:
        self._orgs_table.update_item(
            Key={"organizationId": organization_id},
            UpdateExpression="SET subscriptionStatus = :status",
            ExpressionAttributeValues={":status": "pending_cancellation"},
        )

    def mark_past_due(self, organization_id: str) -> None:
        self._orgs_table.update_item(
            Key={"organizationId": organization_id},
            UpdateExpression="SET subscriptionStatus = :status",
            ExpressionAttributeValues={":status": "past_due"},
        )

    def downgrade_to_free(self, organization_id: str, owner_user_id: str) -> None:
        logger.info("Downgrading org %s to free tier", organization_id)
        self._orgs_table.update_item(
            Key={"organizationId": organization_id},
            UpdateExpression=(
                "SET subscriptionTier = :tier, subscriptionStatus = :status, "
                "stripeSubscriptionId = :subscription, tier1Limit = :tier1_limit, "
                "tier2Limit = :tier2_limit, tier1CreditsUsed = :zero, tier2CreditsUsed = :zero, "
                "welcomeCreditsExpiry = :expiry"
            ),
            ExpressionAttributeValues={
                ":tier": "free",
                ":status": "active",
                ":subscription": None,
                ":tier1_limit": FREE_TIER_LIMITS.tier1,
                ":tier2_limit": FREE_TIER_LIMITS.tier2,
                ":zero": 0,
                ":expiry": None,
            },
        )
        self._swap_cognito_group(owner_user_id, FREE_TIER_GROUP_NAME)

    def _swap_cognito_group(self, user_id: str, target_group: str) -> None:
        if not target_group:
            return

        current_group = self._lookup_user_group(user_id)
        if current_group == target_group:
            return

        if current_group:
            self._cognito.admin_remove_user_from_group(
                UserPoolId=self._user_pool_id,
                Username=user_id,
                GroupName=current_group,
            )
        self._cognito.admin_add_user_to_group(
            UserPoolId=self._user_pool_id,
            Username=user_id,
            GroupName=target_group,
        )

    def _lookup_user_group(self, user_id: str) -> Optional[str]:
        try:
            response = self._cognito.admin_list_groups_for_user(
                UserPoolId=self._user_pool_id,
                Username=user_id,
                Limit=1,
            )
        except self._cognito.exceptions.UserNotFoundException as exc:  # type: ignore[attr-defined]
            raise NotFound(f"Cognito user '{user_id}' not found") from exc
        groups = response.get("Groups", [])
        return groups[0]["GroupName"] if groups else None