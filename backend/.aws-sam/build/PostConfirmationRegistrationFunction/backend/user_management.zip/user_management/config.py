from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Dict, Optional


class ConfigurationError(RuntimeError):
    """Raised when a required environment variable is missing."""


def require_env(name: str) -> str:
    value = os.getenv(name)
    if value is None or value == "":
        raise ConfigurationError(f"Environment variable '{name}' must be defined")
    return value


def optional_env(name: str, default: Optional[str] = None) -> Optional[str]:
    value = os.getenv(name)
    if value is None or value == "":
        return default
    return value


@dataclass(frozen=True)
class TierLimits:
    tier1: int
    tier2: int


@dataclass(frozen=True)
class StripePlanConfig:
    price_id: str
    tier_name: str
    cognito_group: str
    limits: TierLimits


FREE_TIER_LIMITS = TierLimits(tier1=5, tier2=3)
FREE_TIER_WELCOME_DAYS = 30
FREE_TIER_GROUP_NAME = optional_env("FREE_TIER_GROUP_NAME", "Free-Tier") or "Free-Tier"
DEFAULT_LANGUAGE = optional_env("DEFAULT_LANGUAGE", "en") or "en"


def build_stripe_plan_map() -> Dict[str, StripePlanConfig]:
    """Collect plan metadata from environment variables.

    Plans are optional � if a price ID is not configured the plan is skipped.
    """
    plan_definitions = (
        ("INVESTOR_PLAN_PRICE_ID", "investor", "Investor-Tier", TierLimits(tier1=-1, tier2=10)),
        ("PRO_PLAN_PRICE_ID", "pro", "Pro-Tier", TierLimits(tier1=-1, tier2=-1)),
    )

    plans: Dict[str, StripePlanConfig] = {}
    for env_key, tier_name, group, limits in plan_definitions:
        price_id = optional_env(env_key)
        if not price_id:
            continue
        plans[price_id] = StripePlanConfig(
            price_id=price_id,
            tier_name=tier_name,
            cognito_group=group,
            limits=limits,
        )
    return plans


def digest_template_names() -> Dict[str, str]:
    return {
        "en": optional_env("EN_TEMPLATE_NAME", "en_digest_template") or "en_digest_template",
        "he": optional_env("HE_TEMPLATE_NAME", "he_digest_template") or "he_digest_template",
    }


def source_email_address() -> Optional[str]:
    return optional_env("SOURCE_EMAIL")