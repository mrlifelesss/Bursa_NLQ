#3. The Implementation: A Dedicated Handler Function
# In ProcessStripeWebhook/lambda_function.py

# ... (All previous imports, env vars, and setup remain the same) ...
# Ensure your PLAN_MAP is comprehensive:
PLAN_MAP = {
    INVESTOR_PLAN_PRICE_ID: {
        "tier_name": "investor",
        "cognito_group": "Investor-Tier",
        "tier1_limit": -1,
        "tier2_limit": 10
    },
    PRO_PLAN_PRICE_ID: {
        "tier_name": "pro",
        "cognito_group": "Pro-Tier",
        "tier1_limit": -1,
        "tier2_limit": -1
    }
}

def handle_subscription_update(subscription_object):
    """
    Handles a subscription upgrade or downgrade.
    Updates DynamoDB and Cognito to reflect the new plan.
    """
    stripe_customer_id = subscription_object['customer']
    
    # 1. Find the organization record using the GSI on stripeCustomerId
    org_record = find_org_by_stripe_customer_id(stripe_customer_id)
    if not org_record:
        logger.error(f"Received subscription update for unknown customer: {stripe_customer_id}")
        return # Acknowledge and stop processing

    organization_id = org_record['organizationId']
    user_id = org_record['ownerId'] # Assuming you store ownerId
    old_cognito_group = org_record['cognitoGroupName']
    
    # 2. Determine the new plan from the subscription's price ID
    new_price_id = subscription_object['items']['data'][0]['price']['id']
    new_plan_details = PLAN_MAP.get(new_price_id)
    
    if not new_plan_details:
        logger.error(f"Unknown price_id '{new_price_id}' in subscription update for org {organization_id}.")
        return # Acknowledge and stop

    new_cognito_group = new_plan_details['cognito_group']

    # 3. Update the Organization record in DynamoDB with new limits and tier info
    logger.info(f"Updating org {organization_id} from tier {org_record['subscriptionTier']} to {new_plan_details['tier_name']}")
    orgs_table.update_item(
        Key={'organizationId': organization_id},
        UpdateExpression="SET subscriptionTier = :tier, cognitoGroupName = :c_group, "
                         "tier1Limit = :t1l, tier2Limit = :t2l",
        ExpressionAttributeValues={
            ':tier': new_plan_details['tier_name'],
            ':c_group': new_cognito_group,
            ':t1l': new_plan_details['tier1_limit'],
            ':t2l': new_plan_details['tier2_limit']
        }
    )

    # 4. Update the user's group in Cognito
    # IMPORTANT: Only perform the Cognito update if the group is actually changing.
    if old_cognito_group != new_cognito_group:
        logger.info(f"Moving user {user_id} from Cognito group '{old_cognito_group}' to '{new_cognito_group}'")
        try:
            # Remove from old group first
            cognito_client.admin_remove_user_from_group(
                UserPoolId=USER_POOL_ID,
                Username=user_id,
                GroupName=old_cognito_group
            )
            # Add to new group
            cognito_client.admin_add_user_to_group(
                UserPoolId=USER_POOL_ID,
                Username=user_id,
                GroupName=new_cognito_group
            )
        except Exception as e:
            # If this fails, you have an inconsistent state that requires manual fixing. Log it verbosely.
            logger.error(f"CRITICAL: Failed to move user {user_id} between Cognito groups: {str(e)}")
            # You might want to add an alert here (e.g., send an SNS notification)
            raise e # Re-raise to let Stripe know the webhook failed so it will retry.
            
    logger.info(f"Successfully processed subscription update for org {organization_id}")


# --- In your main lambda_handler function ---
# ...
    # ROUTE 2: Plan Change or Cancellation Request
    elif event_type == 'customer.subscription.updated':
        # This event is for more than just upgrades/downgrades.
        # We only care about it if the plan itself has changed, not just for a renewal.
        subscription = data_object
        
        # Check if the user is canceling, which has different logic
        if subscription.get('cancel_at_period_end'):
             # ... handle pending cancellation logic ...
             pass
        else:
             # This is an upgrade, downgrade, or reactivation.
             handle_subscription_update(subscription)

# ... (rest of the webhook handler)