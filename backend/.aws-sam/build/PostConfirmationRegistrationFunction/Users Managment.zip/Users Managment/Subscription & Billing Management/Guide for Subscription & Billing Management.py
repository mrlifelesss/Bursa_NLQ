#Part 1: Implementing the Billing Portal Endpoint
#create_portal_session.py
import os
import boto3
import json
import logging
import stripe

# ... (Standard logging, env var, and Stripe API key setup) ...

def lambda_handler(event, context):
    """
    Creates and returns a one-time Stripe Customer Portal session URL for the
    authenticated user.
    """
    try:
        # 1. Get authenticated user's ID
        user_id = event['requestContext']['authorizer']['claims']['sub']

        # 2. Retrieve user's organizationId and then their stripeCustomerId
        user_record = users_table.get_item(Key={'userId': user_id}).get('Item')
        organization_id = user_record['organizationId']
        org_record = orgs_table.get_item(Key={'organizationId': organization_id}).get('Item')
        stripe_customer_id = org_record.get('stripeCustomerId')

        if not stripe_customer_id:
            # This should not happen for a paying user, but is a good safeguard.
            return {'statusCode': 400, 'body': json.dumps({'error': 'User is not a paying customer'})}

        # 3. Use the Stripe SDK to create the portal session
        # The return_url is where the user will be sent after they are done in the portal.
        portal_session = stripe.billing_portal.Session.create(
            customer=stripe_customer_id,
            return_url='https://YOUR_APP_DOMAIN/account-settings' # Your app's account page URL
        )

        # 4. Return the session URL to the frontend
        return {
            'statusCode': 200,
            'body': json.dumps({'url': portal_session.url})
        }

    except Exception as e:
        logger.error(f"Error creating portal session for user {user_id}: {str(e)}")
        return {'statusCode': 500, 'body': json.dumps({'error': 'Could not create portal session'})}
        
        ==========================================
        
#Part 2: Enhancing the Webhook Handler for All Lifecycle Events
#ProcessStripeWebhook/lambda_function.py  
# ... (All previous imports, env vars, and setup remain the same) ...

def lambda_handler(event, context):
    # --- 1. Signature Verification (Same as before) ---
    try:
        # ... (Stripe signature verification logic) ...
    except Exception as e:
        # ... (Error handling) ...

    # --- 2. Event Routing ---
    event_type = stripe_event['type']
    data_object = stripe_event['data']['object']

    logger.info(f"Processing webhook event: {event_type}")

    # ROUTE 1: New Purchase (from previous guide)
    if event_type == 'checkout.session.completed':
        # ... (Your existing logic for handling a brand new subscription) ...
        pass

    # ROUTE 2: Plan Change or Cancellation Request
    elif event_type == 'customer.subscription.updated':
        subscription = data_object
        stripe_customer_id = subscription['customer']

        # Find the organization by its stripeCustomerId
        org_record = find_org_by_stripe_customer_id(stripe_customer_id)
        if not org_record: return {'statusCode': 200, 'body': 'Org not found, ack.'}
        
        # Scenario A: User CANCELED their plan (to end at period end)
        if subscription.get('cancel_at_period_end'):
            orgs_table.update_item(
                Key={'organizationId': org_record['organizationId']},
                UpdateExpression="SET subscriptionStatus = :status",
                ExpressionAttributeValues={':status': 'pending_cancellation'}
            )
        # Scenario B: User CHANGED their plan (Upgrade/Downgrade)
        else:
            new_price_id = subscription['items']['data'][0]['price']['id']
            plan_details = PLAN_MAP.get(new_price_id)
            if plan_details:
                # Update DynamoDB with new tier, limits
                orgs_table.update_item(...) 
                # Update Cognito Group
                update_cognito_group(...)

    # ROUTE 3: Subscription Officially Ends
    elif event_type == 'customer.subscription.deleted':
        subscription = data_object
        stripe_customer_id = subscription['customer']

        org_record = find_org_by_stripe_customer_id(stripe_customer_id)
        if not org_record: return {'statusCode': 200, 'body': 'Org not found, ack.'}

        # Downgrade user to the free plan
        # This means resetting their record to the same state as a brand new free user
        orgs_table.update_item(
            Key={'organizationId': org_record['organizationId']},
            UpdateExpression="SET subscriptionTier = :free_tier, subscriptionStatus = :active, "
                             "tier1Limit = :t1l, tier2Limit = :t2l, ...", # Reset all values to free tier defaults
            ExpressionAttributeValues={...}
        )
        # Move user back to the 'Free-Tier' Cognito Group
        update_cognito_group(..., new_group='Free-Tier', old_group='Pro-Tier') # old group needs to be known

    # ROUTE 4: Payment Failed
    elif event_type == 'invoice.payment_failed':
        invoice = data_object
        stripe_customer_id = invoice['customer']
        
        org_record = find_org_by_stripe_customer_id(stripe_customer_id)
        if not org_record: return {'statusCode': 200, 'body': 'Org not found, ack.'}

        # Update status to 'past_due'
        orgs_table.update_item(
            Key={'organizationId': org_record['organizationId']},
            UpdateExpression="SET subscriptionStatus = :status",
            ExpressionAttributeValues={':status': 'past_due'}
        )

    # Acknowledge receipt of the webhook
    return {'statusCode': 200, 'body': json.dumps({'status': 'success'})}

# Helper function to find an org by Stripe ID (requires a Global Secondary Index)
def find_org_by_stripe_customer_id(stripe_customer_id):
    # This function would query your GSI on the Organizations table
    # GSI setup: Partition Key = stripeCustomerId
    response = orgs_table.query(...)
    return response['Items'][0] if response.get('Items') else None
    
    
    =============================================
    
    
#Required Database & Logic Modifications
#getSummary/lambda_function.py
# Inside your Lambda handler... after fetching org_record

# Add this check at the very beginning of the authorization logic
subscription_status = org_record.get('subscriptionStatus')
if subscription_status == 'past_due':
    return {'statusCode': 402, 'body': json.dumps({'error': 'Your payment has failed. Please update your billing information.'})}

if subscription_status == 'pending_cancellation':
    # User is still considered active until the period ends, so we allow access.
    pass

# ... (The rest of your existing credit checking logic) ...