#Part 1: Profile Management
#update_profile.py
import os
import boto3
import json
import logging

# ... (Standard logging, env var, and DynamoDB table setup) ...

def lambda_handler(event, context):
    """
    Updates mutable user profile data in the Users DynamoDB table.
    """
    try:
        # 1. Get authenticated user's ID from the token claims
        user_id = event['requestContext']['authorizer']['claims']['sub']
        
        # 2. Get and validate the request body
        body = json.loads(event.get('body', '{}'))
        
        update_expression_parts = []
        expression_attribute_values = {}
        
        # 3. Build the update expression dynamically based on provided fields
        # This is a secure way to prevent users from updating fields they shouldn't.
        if 'name' in body:
            update_expression_parts.append("setName = :n")
            expression_attribute_values[':n'] = body['name']
            
        if 'languagePreference' in body:
            # Add validation for allowed languages
            if body['languagePreference'] in ['en', 'he']:
                update_expression_parts.append("languagePreference = :lang")
                expression_attribute_values[':lang'] = body['languagePreference']

        if not update_expression_parts:
            return {'statusCode': 400, 'body': json.dumps({'error': 'No valid fields to update'})}

        # 4. Execute the atomic update in DynamoDB
        update_expression = ", ".join(update_expression_parts)
        users_table.update_item(
            Key={'userId': user_id},
            UpdateExpression=f"SET {update_expression}",
            ExpressionAttributeValues=expression_attribute_values
        )

        return {'statusCode': 200, 'body': json.dumps({'message': 'Profile updated successfully'})}

    except Exception as e:
        logger.error(f"Error updating profile for user {user_id}: {str(e)}")
        return {'statusCode': 500, 'body': json.dumps({'error': 'Internal server error'})}
        
        ===================================
        
#Part 2: Change Password (for Authenticated Users)
#change_password.py
import os
import boto3
import json
import logging

cognito_client = boto3.client('cognito-idp')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """
    Changes a user's password using their Access Token.
    """
    try:
        body = json.loads(event.get('body', '{}'))
        previous_password = body.get('previousPassword')
        new_password = body.get('newPassword')

        if not all([previous_password, new_password]):
            return {'statusCode': 400, 'body': json.dumps({'error': 'previousPassword and newPassword are required'})}
            
        # 1. Get the Access Token from the Authorization header
        auth_header = event['headers'].get('Authorization', '')
        # The token is typically 'Bearer <token>', so we split and take the second part
        access_token = auth_header.split(' ')[1]

        # 2. Call Cognito's change_password API
        cognito_client.change_password(
            PreviousPassword=previous_password,
            ProposedPassword=new_password,
            AccessToken=access_token
        )

        return {'statusCode': 200, 'body': json.dumps({'message': 'Password changed successfully'})}

    except cognito_client.exceptions.NotAuthorizedException:
        return {'statusCode': 400, 'body': json.dumps({'error': 'Incorrect previous password'})}
    except cognito_client.exceptions.InvalidPasswordException as e:
        # You can pass Cognito's password policy error message directly to the frontend
        return {'statusCode': 400, 'body': json.dumps({'error': str(e)})}
    except Exception as e:
        logger.error(f"Password change failed: {str(e)}")
        return {'statusCode': 500, 'body': json.dumps({'error': 'Internal server error'})}
        
        =======================================
        
#Part 3: Account Deletion
#delete_account.py
import os
import boto3
import json
import logging
import stripe

# ... (Standard setup for all services: DynamoDB, Cognito, Stripe) ...

def lambda_handler(event, context):
    """
    Permanently deletes a user's account and all associated data.
    """
    user_id = event['requestContext']['authorizer']['claims']['sub']
    logger.warning(f"Initiating account deletion for user_id: {user_id}")
    
    try:
        # 1. Fetch user/org data to get Stripe IDs
        user_record = users_table.get_item(Key={'userId': user_id}).get('Item')
        if not user_record:
            # User might already be partially deleted, so we can treat as success
            return {'statusCode': 200, 'body': json.dumps({'message': 'User already deleted'})}
        
        organization_id = user_record['organizationId']
        org_record = orgs_table.get_item(Key={'organizationId': organization_id}).get('Item')
        
        # 2. STEP 1: Cancel Stripe Subscription (if it exists)
        stripe_subscription_id = org_record.get('stripeSubscriptionId')
        if stripe_subscription_id:
            try:
                stripe.Subscription.delete(stripe_subscription_id)
                logger.info(f"Canceled Stripe subscription {stripe_subscription_id} for user {user_id}")
            except stripe.error.InvalidRequestError as e:
                # If subscription is already canceled, that's fine.
                logger.warning(f"Stripe subscription {stripe_subscription_id} already canceled or not found: {str(e)}")
        
        # 3. STEP 2: Delete user from Cognito
        try:
            cognito_client.admin_delete_user(
                UserPoolId=USER_POOL_ID,
                Username=user_id
            )
            logger.info(f"Deleted user {user_id} from Cognito User Pool.")
        except cognito_client.exceptions.UserNotFoundException:
            logger.warning(f"User {user_id} already deleted from Cognito.")

        # 4. STEP 3: Delete records from DynamoDB
        # Best to delete the org record first, then the user record
        if org_record:
            orgs_table.delete_item(Key={'organizationId': organization_id})
            logger.info(f"Deleted organization {organization_id} from DynamoDB.")
        
        users_table.delete_item(Key={'userId': user_id})
        logger.info(f"Deleted user {user_id} from DynamoDB.")
        
        return {'statusCode': 200, 'body': json.dumps({'message': 'Account deleted successfully'})}

    except Exception as e:
        logger.error(f"CRITICAL: Account deletion failed for {user_id}: {str(e)}")
        # This error requires manual investigation by an admin
        return {'statusCode': 500, 'body': json.dumps({'error': 'An error occurred during account deletion.'})}
        
        
       
        

