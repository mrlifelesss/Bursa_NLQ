#Part 2.2: API Endpoints for Adding/Removing Items
#Endpoint 1: Add to Watchlist
#addToWatchlist
# In addToWatchlist/lambda_function.py
import boto3
import json

watchlist_table = boto3.resource('dynamodb').Table('WatchlistItems')

def lambda_handler(event, context):
    user_id = event['requestContext']['authorizer']['claims']['sub']
    company_id = event['pathParameters']['companyId']
    
    item = {
        'userId': user_id,
        'companyId': company_id
    }
    
    try:
        watchlist_table.put_item(Item=item)
        return {'statusCode': 201, 'body': json.dumps({'status': 'created'})}
    except Exception as e:
        # Log the error
        return {'statusCode': 500, 'body': json.dumps({'error': 'Could not add to watchlist'})}

=========================================

#Endpoint 2: Remove from Watchlist
#removeFromWatchlist
# In removeFromWatchlist/lambda_function.py
import boto3
import json

watchlist_table = boto3.resource('dynamodb').Table('WatchlistItems')

def lambda_handler(event, context):
    user_id = event['requestContext']['authorizer']['claims']['sub']
    company_id = event['pathParameters']['companyId']
    
    key = {
        'userId': user_id,
        'companyId': company_id
    }
    
    try:
        watchlist_table.delete_item(Key=key)
        return {'statusCode': 204, 'body': ''} # 204 No Content is standard for successful DELETE
    except Exception as e:
        # Log the error
        return {'statusCode': 500, 'body': json.dumps({'error': 'Could not remove from watchlist'})}
                
        =================================
#Daily Digest Lambda
#### **Crucial Prerequisites (One-time Setup)**

1.  **DynamoDB GSI:** You MUST have a Global Secondary Index on your `Announcements` table to allow for efficient querying by date.
    *   **Suggestion:** Create a GSI with a Partition Key like `status` (which could always be `"PUBLISHED"`) and a Sort Key of `publicationDate` (String, in ISO 8601 format like `2025-09-25T10:30:00Z`).
2.  **SES Templates:** You MUST create two email templates in Amazon SES as described previously: `en_digest_template` and `he_digest_template`.
3.  **Verified SES "From" Address:** The email address used in the `SOURCE_EMAIL` environment variable must be verified in Amazon SES.
 
import os
import boto3
import json
import logging
from datetime import datetime, timedelta, timezone
from collections import defaultdict

# =====================================================================================
# 1. INITIALIZATION & CONFIGURATION
# =====================================================================================

# Standard AWS Lambda logging setup
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients outside the handler for performance (context reuse)
dynamodb = boto3.resource('dynamodb')
ses_client = boto3.client('ses')

# Fetch configuration from environment variables
try:
    USERS_TABLE_NAME = os.environ['USERS_TABLE_NAME']
    ANNOUNCEMENTS_TABLE_NAME = os.environ['ANNOUNCEMENTS_TABLE_NAME']
    WATCHLIST_TABLE_NAME = os.environ['WATCHLIST_TABLE_NAME']
    ANNOUNCEMENTS_GSI_NAME = os.environ['ANNOUNCEMENTS_GSI_NAME'] # Name of the GSI for date queries
    SOURCE_EMAIL = os.environ['SOURCE_EMAIL'] # Your verified SES 'From' address
    EN_TEMPLATE_NAME = os.environ.get('EN_TEMPLATE_NAME', 'en_digest_template')
    HE_TEMPLATE_NAME = os.environ.get('HE_TEMPLATE_NAME', 'he_digest_template')
except KeyError as e:
    logger.error(f"FATAL: Missing critical environment variable: {str(e)}")
    raise e

# Get DynamoDB table resources
users_table = dynamodb.Table(USERS_TABLE_NAME)
announcements_table = dynamodb.Table(ANNOUNCEMENTS_TABLE_NAME)
watchlist_table = dynamodb.Table(WATCHLIST_TABLE_NAME)


# =====================================================================================
# 2. HELPER FUNCTIONS (Data Fetching)
# =====================================================================================

def get_recent_announcements():
    """Queries DynamoDB for all announcements published in the last 24 hours."""
    logger.info("Fetching announcements from the last 24 hours...")
    
    # Calculate timestamps
    now = datetime.now(timezone.utc)
    twenty_four_hours_ago = now - timedelta(days=1)
    
    # Query the GSI for announcements within the date range
    response = announcements_table.query(
        IndexName=ANNOUNCEMENTS_GSI_NAME,
        # This assumes a GSI with Partition Key 'status' and Sort Key 'publicationDate'
        KeyConditionExpression="status = :status AND publicationDate BETWEEN :start_date AND :end_date",
        ExpressionAttributeValues={
            ':status': 'PUBLISHED',
            ':start_date': twenty_four_hours_ago.isoformat(),
            ':end_date': now.isoformat()
        }
    )
    logger.info(f"Found {len(response.get('Items', []))} new announcements.")
    return response.get('Items', [])

def get_all_watchlist_items():
    """Scans the entire WatchlistItems table to get all user-company relationships."""
    logger.info("Scanning WatchlistItems table...")
    
    scan_kwargs = {}
    items = []
    # A paginated scan is crucial for scalability
    while True:
        response = watchlist_table.scan(**scan_kwargs)
        items.extend(response.get('Items', []))
        if 'LastEvaluatedKey' not in response:
            break
        scan_kwargs['ExclusiveStartKey'] = response['LastEvaluatedKey']
        
    logger.info(f"Found {len(items)} total watchlist entries.")
    return items

def get_user_details(user_ids):
    """
    Fetches details (email, name, lang) for a list of users using BatchGetItem.
    Returns a dictionary mapping userId to their details.
    """
    if not user_ids:
        return {}
        
    logger.info(f"Fetching details for {len(user_ids)} users...")
    user_details = {}
    
    # DynamoDB BatchGetItem can handle up to 100 keys at once
    keys_to_get = [{'userId': uid} for uid in user_ids]
    
    for i in range(0, len(keys_to_get), 100):
        chunk = keys_to_get[i:i + 100]
        response = dynamodb.batch_get_item(
            RequestItems={USERS_TABLE_NAME: {'Keys': chunk}}
        )
        for item in response['Responses'].get(USERS_TABLE_NAME, []):
            user_details[item['userId']] = item
            
    logger.info(f"Successfully fetched details for {len(user_details)} users.")
    return user_details


# =====================================================================================
# 3. MAIN LAMBDA HANDLER
# =====================================================================================

def lambda_handler(event, context):
    """
    Main function triggered by EventBridge. Orchestrates the entire digest process.
    """
    logger.info("Daily Digest process started.")

    # STEP 1: Fetch all necessary data from DynamoDB
    recent_announcements = get_recent_announcements()
    if not recent_announcements:
        logger.info("No new announcements in the last 24 hours. Process finished.")
        return {'statusCode': 200, 'body': 'No new announcements.'}

    all_watchlist_entries = get_all_watchlist_items()
    if not all_watchlist_entries:
        logger.info("No users have watchlists. Process finished.")
        return {'statusCode': 200, 'body': 'No watchlists found.'}

    # STEP 2: Build the "In-Memory" maps
    # Map 1: companyId -> list of userIds who watch it
    watchlist_map = defaultdict(list)
    for entry in all_watchlist_entries:
        watchlist_map[entry['companyId']].append(entry['userId'])

    # Map 2: userId -> list of announcements they should receive
    digest_map = defaultdict(list)
    for announcement in recent_announcements:
        company_id = announcement['companyId']
        interested_users = watchlist_map.get(company_id, [])
        for user_id in interested_users:
            digest_map[user_id].append(announcement)
    
    if not digest_map:
        logger.info("No users to alert for the recent announcements. Process finished.")
        return {'statusCode': 200, 'body': 'No alerts to send.'}

    # STEP 3: Fetch details for all users who will receive a digest
    user_ids_to_notify = list(digest_map.keys())
    user_details = get_user_details(user_ids_to_notify)

    # STEP 4: Loop through the digest map and send emails via SES
    emails_sent = 0
    emails_failed = 0
    for user_id, announcements_to_send in digest_map.items():
        user_info = user_details.get(user_id)
        if not user_info or 'email' not in user_info:
            logger.warning(f"Skipping user {user_id}: details or email not found.")
            emails_failed += 1
            continue
        
        # Choose the correct template based on user preference
        template_name = HE_TEMPLATE_NAME if user_info.get('languagePreference') == 'he' else EN_TEMPLATE_NAME

        # Format the data exactly as the SES template expects
        template_data = {
            'name': user_info.get('name', 'Valued Investor'),
            'update_count': len(announcements_to_send),
            'announcements': [
                {
                    'companyName': ann.get('companyName', 'N/A'),
                    'reportTitle': ann.get('title', 'N/A'),
                    'summary': ann.get('tier1Summary', 'Summary not available.'), # Make sure your field names match!
                    'link': f"https://yourapp.com/announcement/{ann.get('announcementId')}"
                } for ann in announcements_to_send
            ]
        }

        try:
            ses_client.send_templated_email(
                Source=SOURCE_EMAIL,
                Destination={'ToAddresses': [user_info['email']]},
                Template=template_name,
                TemplateData=json.dumps(template_data)
            )
            emails_sent += 1
        except Exception as e:
            emails_failed += 1
            logger.error(f"Failed to send email to {user_id} ({user_info['email']}): {str(e)}")

    logger.info(f"Daily Digest process finished. Sent: {emails_sent}, Failed: {emails_failed}.")
    return {'statusCode': 200, 'body': f'Process complete. Sent: {emails_sent}, Failed: {emails_failed}.'} 
    
    ====
    
#IAM Policy for the Lambda Execution Role: The function needs these permissions.   
    {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "DynamoDBReadPermissions",
            "Effect": "Allow",
            "Action": [
                "dynamodb:Scan",
                "dynamodb:Query",
                "dynamodb:BatchGetItem"
            ],
            "Resource": [
                "arn:aws:dynamodb:REGION:ACCOUNT_ID:table/Users",
                "arn:aws:dynamodb:REGION:ACCOUNT_ID:table/Announcements",
                "arn:aws:dynamodb:REGION:ACCOUNT_ID:table/Announcements/index/AnnouncementsByDateGSI",
                "arn:aws:dynamodb:REGION:ACCOUNT_ID:table/WatchlistItems"
            ]
        },
        {
            "Sid": "SESSendPermission",
            "Effect": "Allow",
            "Action": "ses:SendTemplatedEmail",
            "Resource": "arn:aws:ses:REGION:ACCOUNT_ID:identity/yourdomain.com"
        }
    ]
}