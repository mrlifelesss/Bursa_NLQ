#Step 1: Get User Identity and Request Parameters
# Inside your Lambda handler
def lambda_handler(event, context):
    # Get the unique user ID provided by the Cognito Authorizer
    user_id = event['requestContext']['authorizer']['claims']['sub']
    
    # Get what the user is asking for (e.g., from a URL like /summary/{id}?tier=1)
    announcement_id = event['pathParameters']['id']
    requested_tier = int(event['queryStringParameters']['tier']) # e.g., 1 or 2
	
	==========================================
#Step 2: Retrieve the User's Entitlements	
# Inside your Lambda handler...
try:
    # First, get the user record to find their organization
    user_record = users_table.get_item(Key={'userId': user_id}).get('Item')
    if not user_record:
        return {'statusCode': 404, 'body': json.dumps({'error': 'User not found'})}
    organization_id = user_record['organizationId']

    # Now, get the organization record which holds all subscription data
    org_record = orgs_table.get_item(Key={'organizationId': organization_id}).get('Item')
    if not org_record:
        return {'statusCode': 404, 'body': json.dumps({'error': 'Organization not found'})}
        
except Exception as e:
    logger.error(f"Failed to fetch user/org data for {user_id}: {str(e)}")
    return {'statusCode': 500, 'body': json.dumps({'error': 'Internal database error'})}
	==========================================
	
#Step 3: Handle Monthly Credit Resets (On-the-Fly)
# Inside your Lambda handler... after fetching org_record
import datetime

now = datetime.datetime.now(datetime.timezone.utc)
reset_date_str = org_record.get('creditCycleResetDate')

if reset_date_str:
    reset_date = datetime.datetime.fromisoformat(reset_date_str)
    if now > reset_date:
        # The month has rolled over. Reset the credits!
        new_reset_date = (now + datetime.timedelta(days=30)).isoformat()
        
        logger.info(f"Resetting monthly credits for organization {organization_id}")
        orgs_table.update_item(
            Key={'organizationId': organization_id},
            UpdateExpression="SET tier1CreditsUsed = :zero, tier2CreditsUsed = :zero, creditCycleResetDate = :nrd",
            ExpressionAttributeValues={
                ':zero': 0,
                ':nrd': new_reset_date
            }
        )
        # Update the local copy of the record to reflect the reset
        org_record['tier1CreditsUsed'] = 0
        org_record['tier2CreditsUsed'] = 0
        org_record['creditCycleResetDate'] = new_reset_date
		
		==============================================
		
#Step 4: The Decision Engine
# Inside your Lambda handler... after the reset check

subscription_tier = org_record.get('subscriptionTier')
tier_to_check = None

if requested_tier == 1:
    tier1_limit = org_record.get('tier1Limit', 0)
    # Check for unlimited access first
    if tier1_limit == -1:
        pass # Allow access
    # Check if they have credits remaining
    elif org_record.get('tier1CreditsUsed', 0) < tier1_limit:
        tier_to_check = 'tier1'
    else:
        return {'statusCode': 402, 'body': json.dumps({'error': 'Tier 1 credit limit exceeded'})}

elif requested_tier == 2:
    tier2_limit = org_record.get('tier2Limit', 0)
    # Check for unlimited access
    if tier2_limit == -1:
        pass # Allow access
    # Special check for free tier's welcome credits expiry
    elif subscription_tier == 'free':
        expiry_date = datetime.datetime.fromisoformat(org_record.get('welcomeCreditsExpiry'))
        if now > expiry_date:
            return {'statusCode': 403, 'body': json.dumps({'error': 'Welcome credits have expired'})}
        if org_record.get('tier2CreditsUsed', 0) < tier2_limit:
            tier_to_check = 'tier2'
        else:
             return {'statusCode': 402, 'body': json.dumps({'error': 'Welcome credit limit exceeded'})}
    # Check for investor tier credits
    elif org_record.get('tier2CreditsUsed', 0) < tier2_limit:
        tier_to_check = 'tier2'
    else:
        return {'statusCode': 402, 'body': json.dumps({'error': 'Tier 2 credit limit exceeded'})}

else:
    return {'statusCode': 400, 'body': json.dumps({'error': 'Invalid tier requested'})}
	
	==================================================
	
#Step 5: Consume Credit and Fetch Data
# Inside your Lambda handler... after the decision engine logic

# If tier_to_check is not None, it means we need to consume a credit
if tier_to_check:
    try:
        # This is the atomic update operation
        # It only succeeds if the user still has credits available
        credit_field_to_update = f"{tier_to_check}CreditsUsed"
        limit_field = f"{tier_to_check}Limit"
        
        orgs_table.update_item(
            Key={'organizationId': organization_id},
            UpdateExpression=f"SET {credit_field_to_update} = {credit_field_to_update} + :inc",
            ConditionExpression=f"{credit_field_to_update} < :limit",
            ExpressionAttributeValues={
                ':inc': 1,
                ':limit': org_record[limit_field]
            }
        )
        logger.info(f"Successfully consumed a {tier_to_check} credit for {organization_id}")

    except dynamodb.meta.client.exceptions.ConditionalCheckFailedException:
        # This is a rare edge case where the user's credits ran out
        # between the initial check and the atomic update (e.g., in another browser tab).
        logger.warning(f"Atomic credit update failed for {organization_id}. They are out of credits.")
        return {'statusCode': 429, 'body': json.dumps({'error': 'Credit limit reached'})}

# --- If we reach this point, the user is fully authorized ---

# 6. Perform the actual work (e.g., call the AI service)
# summary_data = get_summary_from_ai_service(announcement_id, requested_tier)
summary_data = {"id": announcement_id, "tier": requested_tier, "content": "This is the AI summary."}

# 7. Return the data
return {
    'statusCode': 200,
    'headers': { 'Content-Type': 'application/json' },
    'body': json.dumps(summary_data)
}

===============================================================

