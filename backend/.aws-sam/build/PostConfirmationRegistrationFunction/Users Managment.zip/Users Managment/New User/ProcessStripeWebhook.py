import os
import boto3
import json
import logging
import stripe

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb')
cognito_client = boto.client('cognito-idp')

# --- Environment Variable Configuration ---
# It's critical to fail fast if these are not configured.
try:
    USERS_TABLE_NAME = os.environ['USERS_TABLE_NAME']
    ORGS_TABLE_NAME = os.environ['ORGS_TABLE_NAME']
    USER_POOL_ID = os.environ['USER_POOL_ID']
    
    # Stripe secrets
    STRIPE_API_KEY = os.environ['STRIPE_API_KEY']
    STRIPE_WEBHOOK_SECRET = os.environ['STRIPE_WEBHOOK_SECRET']
    
    # Mapping from Stripe Price ID to our internal plan names
    INVESTOR_PLAN_PRICE_ID = os.environ['INVESTOR_PLAN_PRICE_ID']
    PRO_PLAN_PRICE_ID = os.environ['PRO_PLAN_PRICE_ID']

except KeyError as e:
    logger.error(f"CRITICAL: Missing environment variable: {str(e)}")
    # In a real API Gateway proxy integration, you'd return a 500 here
    raise e

# --- Static Configuration ---
users_table = dynamodb.Table(USERS_TABLE_NAME)
orgs_table = dynamodb.Table(ORGS_TABLE_NAME)
stripe.api_key = STRIPE_API_KEY

# This maps the Stripe Price ID to the data we need to update in our system
PLAN_MAP = {
    INVESTOR_PLAN_PRICE_ID: {
        "tier_name": "investor",
        "cognito_group": "Investor-Tier",
        "tier1_limit": -1, # -1 signifies unlimited
        "tier2_limit": 10
    },
    PRO_PLAN_PRICE_ID: {
        "tier_name": "pro",
        "cognito_group": "Pro-Tier",
        "tier1_limit": -1,
        "tier2_limit": -1
    }
}


def lambda_handler(event, context):
    """
    Handles the Stripe 'checkout.session.completed' webhook.
    Verifies the request, then upgrades the user's plan in DynamoDB and Cognito.
    """
    
    # The raw body and signature header are needed for verification
    raw_body = event.get('body')
    signature_header = event['headers'].get('stripe-signature')

    if not raw_body or not signature_header:
        logger.error("Missing body or stripe-signature header.")
        return {'statusCode': 400, 'body': json.dumps({'error': 'Bad Request'})}
    
    # 1. --- SECURITY: Verify the webhook signature ---
    try:
        stripe_event = stripe.Webhook.construct_event(
            payload=raw_body, sig_header=signature_header, secret=STRIPE_WEBHOOK_SECRET
        )
    except (ValueError, stripe.error.SignatureVerificationError) as e:
        logger.error(f"Stripe signature verification failed: {str(e)}")
        return {'statusCode': 400, 'body': json.dumps({'error': 'Invalid signature'})}

    # 2. --- Process only the event we care about ---
    if stripe_event['type'] == 'checkout.session.completed':
        session = stripe_event['data']['object']
        logger.info(f"Processing checkout.session.completed for session: {session['id']}")

        # 3. --- Extract crucial data from the session object ---
        user_id = session.get('client_reference_id')
        stripe_customer_id = session.get('customer')
        stripe_subscription_id = session.get('subscription')
        
        # Expand the line items to find out which price was purchased
        line_items = stripe.checkout.Session.list_line_items(session['id'], limit=1)
        price_id = line_items['data'][0]['price']['id']

        if not all([user_id, stripe_customer_id, stripe_subscription_id, price_id]):
            logger.error(f"Webhook payload missing critical data for session {session['id']}")
            return {'statusCode': 400, 'body': json.dumps({'error': 'Payload missing data'})}

        # 4. --- Determine the new plan ---
        plan_details = PLAN_MAP.get(price_id)
        if not plan_details:
            logger.error(f"Unknown price_id '{price_id}' received. Cannot map to a plan.")
            # Return 200 OK so Stripe doesn't retry for an un-plannable error
            return {'statusCode': 200, 'body': json.dumps({'status': 'unsupported plan'})}
            
        try:
            # 5. --- Get the user's organizationId from the Users table ---
            user_record = users_table.get_item(Key={'userId': user_id}).get('Item')
            if not user_record:
                raise ValueError(f"User with userId '{user_id}' not found in Users table.")
            organization_id = user_record['organizationId']

            # 6. --- Update the Organization record in DynamoDB ---
            logger.info(f"Upgrading organization {organization_id} to tier '{plan_details['tier_name']}'")
            orgs_table.update_item(
                Key={'organizationId': organization_id},
                UpdateExpression="SET subscriptionTier = :tier, subscriptionStatus = :status, "
                                 "stripeCustomerId = :cid, stripeSubscriptionId = :sid, "
                                 "tier1Limit = :t1l, tier2Limit = :t2l, "
                                 "welcomeCreditsExpiry = :wce_null", # Null out welcome credits
                ExpressionAttributeValues={
                    ':tier': plan_details['tier_name'],
                    ':status': 'active',
                    ':cid': stripe_customer_id,
                    ':sid': stripe_subscription_id,
                    ':t1l': plan_details['tier1_limit'],
                    ':t2l': plan_details['tier2_limit'],
                    ':wce_null': None
                }
            )

            # 7. --- Update the user's group in Cognito ---
            # This is a two-step process: remove from old group, add to new group.
            new_cognito_group = plan_details['cognito_group']
            logger.info(f"Moving user {user_id} from 'Free-Tier' to '{new_cognito_group}'")
            
            cognito_client.admin_remove_user_from_group(
                UserPoolId=USER_POOL_ID, Username=user_id, GroupName='Free-Tier'
            )
            cognito_client.admin_add_user_to_group(
                UserPoolId=USER_POOL_ID, Username=user_id, GroupName=new_cognito_group
            )

        except Exception as e:
            logger.error(f"Failed to process upgrade for user {user_id}: {str(e)}")
            # Return 500 to signal to Stripe that it should retry this webhook
            return {'statusCode': 500, 'body': json.dumps({'error': 'Internal Server Error'})}
            
    # 8. --- Acknowledge other event types ---
    else:
        logger.info(f"Received unhandled event type: {stripe_event['type']}")

    # Return a 200 OK to Stripe to acknowledge receipt of the webhook
    return {'statusCode': 200, 'body': json.dumps({'status': 'success'})}