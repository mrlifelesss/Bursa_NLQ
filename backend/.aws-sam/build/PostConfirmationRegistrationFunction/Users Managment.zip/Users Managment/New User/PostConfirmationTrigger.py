import os
import boto3
import uuid
import datetime
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients from the boto3 library
# These are initialized outside the handler to take advantage of Lambda's execution context reuse
dynamodb = boto3.resource('dynamodb')
cognito_client = boto3.client('cognito-idp')

# Fetch environment variables
# It's critical to fail fast if these are not configured
try:
    USERS_TABLE_NAME = os.environ['USERS_TABLE_NAME']
    ORGS_TABLE_NAME = os.environ['ORGS_TABLE_NAME']
    USER_POOL_ID = os.environ['USER_POOL_ID']
except KeyError as e:
    logger.error(f"CRITICAL: Missing environment variable: {str(e)}")
    raise e # Stop execution if configuration is missing

users_table = dynamodb.Table(USERS_TABLE_NAME)
orgs_table = dynamodb.Table(ORGS_TABLE_NAME)


def lambda_handler(event, context):
    """
    This function is triggered by a Cognito Post Confirmation event.
    It creates a User record and a corresponding Organization record (on the free tier)
    in DynamoDB, and adds the user to the 'Free-Tier' Cognito group.
    """
    logger.info(f"Received Cognito event: {event}")

    # Extract user attributes from the Cognito event object
    # The 'userName' is the unique 'sub' identifier for the user
    user_id = event['userName']
    user_attributes = event['request']['userAttributes']
    email = user_attributes.get('email')
    name = user_attributes.get('name', 'New User') # Provide a default name if not present

    if not email:
        logger.error("User email is missing from the event. Cannot process user.")
        # We still return the event to not fail the Cognito flow, but the user won't be in our DB
        return event

    try:
        # 1. Generate new IDs and timestamps
        organization_id = str(uuid.uuid4())
        now = datetime.datetime.now(datetime.timezone.utc)
        thirty_days_from_now = now + datetime.timedelta(days=30)

        # Convert datetimes to ISO 8601 string format, which is standard for DynamoDB
        current_time_iso = now.isoformat()
        expiry_time_iso = thirty_days_from_now.isoformat()

        logger.info(f"Creating records for user_id: {user_id} in organization_id: {organization_id}")

        # 2. Construct the User and Organization items for DynamoDB
        user_item = {
            'userId': user_id,
            'organizationId': organization_id,
            'email': email,
            'name': name,
            'roleInOrg': 'owner',
            'languagePreference': 'en',  # Default language
            'createdAt': current_time_iso
        }

        # This object contains all the default settings for a new "Basic Plan" user
        org_item = {
            'organizationId': organization_id,
            'subscriptionTier': 'free',
            'subscriptionStatus': 'active',
            'createdAt': current_time_iso,
            'stripeCustomerId': None,
            'stripeSubscriptionId': None,
            'tier1Limit': 5,
            'tier1CreditsUsed': 0,
            'tier2Limit': 3,
            'tier2CreditsUsed': 0,
            'creditCycleResetDate': expiry_time_iso,
            'welcomeCreditsExpiry': expiry_time_iso
        }

        # 3. Write items to DynamoDB tables
        logger.info(f"Writing user item to {USERS_TABLE_NAME}: {user_item}")
        users_table.put_item(Item=user_item)

        logger.info(f"Writing organization item to {ORGS_TABLE_NAME}: {org_item}")
        orgs_table.put_item(Item=org_item)

        # 4. Add the user to the 'Free-Tier' Cognito User Group
        group_name = 'Free-Tier'
        logger.info(f"Adding user {user_id} to Cognito group '{group_name}' in pool {USER_POOL_ID}")
        cognito_client.admin_add_user_to_group(
            UserPoolId=USER_POOL_ID,
            Username=user_id,
            GroupName=group_name
        )

        logger.info(f"Successfully processed new user {user_id}.")

    except Exception as e:
        logger.error(f"An error occurred while processing user {user_id}: {str(e)}")
        # Re-raise the exception to ensure the Lambda invocation is marked as a failure
        # and Cognito is aware that the post-confirmation hook failed.
        raise e

    # 5. Return the original event object to Cognito to complete the flow
    return event